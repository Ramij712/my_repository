package com.example.nearmedemo;

public interface SavedLocationInterface {

    void onLocationClick(SavedPlaceModel savedPlaceModel);
}
